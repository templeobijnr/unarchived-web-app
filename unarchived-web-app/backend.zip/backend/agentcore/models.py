# models.py for ai app
