# serializers.py for ai app
