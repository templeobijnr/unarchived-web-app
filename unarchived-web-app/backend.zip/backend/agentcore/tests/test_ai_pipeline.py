import io
from unittest import mock
from django.contrib.auth import get_user_model
from django.urls import reverse
from rest_framework.test import APITestCase, APIClient
from rest_framework_simplejwt.tokens import RefreshToken
from dpgs.models import DigitalProductGenome  # Correct import

User = get_user_model()

class AIFlowTestCase(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(email="testuser@example.com", password="testpass123")
        self.client = APIClient()
        refresh = RefreshToken.for_user(self.user)
        self.client.credentials(HTTP_AUTHORIZATION=f'Bearer {str(refresh.access_token)}')

    @mock.patch("agentcore.views.agent.create_co_pilot_agent")
    def test_ai_chat_creates_dpg(self, mock_create_agent):
        # Arrange
        mock_agent_instance = mock.Mock()
        mock_agent_instance.run.return_value = "This is a mocked response."
        mock_create_agent.return_value = mock_agent_instance

        url = reverse("agentcore:ai-chat")
        data = {"message": "Design a minimalist chair"}

        # Act
        response = self.client.post(url, data, format="json")

        # Assert
        self.assertEqual(response.status_code, 200)
        self.assertIn("response", response.data)
        self.assertEqual(response.data["response"], "This is a mocked response.")

    def test_upload_file_triggers_ocr(self):
        url = reverse("files:file-list")
        test_file = io.BytesIO(b"Fake image content")
        test_file.name = "test.jpg"
        data = {"file": test_file, "file_type": "image"}

        response = self.client.post(url, data, format="multipart")
        self.assertIn(response.status_code, [200, 201, 202])  # Accept various success codes

    def test_dpg_model_creation(self):
        dpg = DigitalProductGenome.objects.create(
            name="Test Product",
            user=self.user,
            data={"material": "cotton", "color": "blue"},
        )
        self.assertEqual(dpg.name, "Test Product")
        self.assertEqual(dpg.data["material"], "cotton")
