from langchain_core.tools import tool
import json
from decouple import config
from langchain_community.chat_models import ChatOpenAI

@tool
def file_parser_tool(file_content: str) -> dict:
    '''Parse raw file content into structured components.'''
    # Simulate logic – in reality, you'd use OCR or pattern matching
    return {"extracted_text": file_content[:100], "summary": "Sample parsed structure"}

@tool
def dpg_builder_tool(prompt: str) -> dict:
    '''Use LLM to extract product title and build DPG from a natural language prompt.'''
    llm = ChatOpenAI(
        model_name=config("OPENAI_MODEL", default="gpt-4"),
        openai_api_key=config("OPENAI_API_KEY"),
        temperature=0
    )
    title_prompt = f"Extract a clean product title from this request: '{prompt}'"

    response = llm.invoke(title_prompt)

    return {
        "title": response.content.strip(),
        "version": "1.0",
        "data": {"summary": prompt},
        "stage": "created"
    }
    
@tool
def rfq_generator_tool(dpg_data: dict) -> dict:
    '''Generate a request-for-quote from an approved DPG.'''
    return {
        "title": f"RFQ for {dpg_data.get('title', 'Unnamed')}",
        "category": dpg_data.get("data", {}).get("category", "Uncategorized"),
        "status": "draft"
    }