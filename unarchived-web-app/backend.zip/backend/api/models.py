from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils import timezone


class Supplier(models.Model):
    """Enhanced supplier model with verification system"""
    
    # Basic Information
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    legal_name = models.CharField(max_length=255, blank=True)
    logo = models.URLField(max_length=500, blank=True)
    
    # Verification Status
    VERIFICATION_STATUS_CHOICES = [
        ('pending', 'Pending Verification'),
        ('verified', 'Verified'),
        ('rejected', 'Rejected'),
        ('suspended', 'Suspended'),
    ]
    verification_status = models.CharField(
        max_length=20, 
        choices=VERIFICATION_STATUS_CHOICES, 
        default='pending'
    )
    verification_date = models.DateTimeField(null=True, blank=True)
    verified_by = models.ForeignKey(
        User, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True,
        related_name='verified_suppliers'
    )
    
    # Business Information
    business_type = models.CharField(max_length=100, blank=True)  # Manufacturer, Trading Company, etc.
    year_established = models.IntegerField(null=True, blank=True)
    employee_count = models.CharField(max_length=50, blank=True)
    annual_revenue = models.CharField(max_length=100, blank=True)
    
    # Certifications & Quality
    certifications = models.JSONField(default=list)
    quality_standards = models.JSONField(default=list)  # ISO, CE, RoHS, etc.
    audit_reports = models.JSONField(default=list)
    
    # Contact Information
    contact_email = models.EmailField()
    contact_phone = models.CharField(max_length=50)
    contact_address = models.TextField()
    website = models.URLField(blank=True)
    
    # Location & Shipping
    region = models.CharField(max_length=255)
    country = models.CharField(max_length=100, blank=True)
    shipping_regions = models.JSONField(default=list)
    lead_time_range = models.CharField(max_length=100, blank=True)  # "7-14 days"
    
    # Performance Metrics
    reliability = models.IntegerField(
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        help_text="Reliability score from 0-100",
        default=50
    )
    response_time_avg = models.IntegerField(
        help_text="Average response time in hours",
        default=48
    )
    quote_acceptance_rate = models.DecimalField(
        max_digits=5, 
        decimal_places=2, 
        help_text="Percentage of accepted quotes",
        default=0.0
    )
    
    # Categories & Capabilities
    category = models.CharField(max_length=100)  # Keep for backward compatibility
    categories = models.JSONField(default=list)
    capabilities = models.JSONField(default=list)
    product_catalog = models.JSONField(default=list)
    
    # Financial & Payment
    payment_terms = models.CharField(max_length=100, blank=True)
    minimum_order_value = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    credit_rating = models.CharField(max_length=10, blank=True)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    last_activity = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-reliability', '-verification_status', 'name']
        indexes = [
            models.Index(fields=['verification_status']),
            models.Index(fields=['categories']),
            models.Index(fields=['region']),
            models.Index(fields=['reliability']),
        ]
    
    def __str__(self):
        return f"{self.name} ({self.verification_status})"


class SupplierContact(models.Model):
    """Supplier contact management"""
    
    CONTACT_TYPE_CHOICES = [
        ('primary', 'Primary Contact'),
        ('sales', 'Sales Contact'),
        ('technical', 'Technical Contact'),
        ('quality', 'Quality Contact'),
        ('logistics', 'Logistics Contact'),
    ]
    
    supplier = models.ForeignKey(Supplier, on_delete=models.CASCADE, related_name='contacts')
    contact_type = models.CharField(max_length=20, choices=CONTACT_TYPE_CHOICES)
    
    # Contact Information
    name = models.CharField(max_length=255)
    title = models.CharField(max_length=255, blank=True)
    email = models.EmailField()
    phone = models.CharField(max_length=50, blank=True)
    mobile = models.CharField(max_length=50, blank=True)
    wechat = models.CharField(max_length=100, blank=True)
    whatsapp = models.CharField(max_length=100, blank=True)
    
    # Communication Preferences
    preferred_contact_method = models.CharField(
        max_length=20,
        choices=[
            ('email', 'Email'),
            ('phone', 'Phone'),
            ('wechat', 'WeChat'),
            ('whatsapp', 'WhatsApp'),
        ],
        default='email'
    )
    timezone = models.CharField(max_length=50, blank=True)
    working_hours = models.CharField(max_length=100, blank=True)
    
    # Status
    is_active = models.BooleanField(default=True)
    is_verified = models.BooleanField(default=False)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        unique_together = ['supplier', 'contact_type']
        ordering = ['supplier', 'contact_type']
    
    def __str__(self):
        return f"{self.supplier.name} - {self.get_contact_type_display()}: {self.name}"


class SupplierVerification(models.Model):
    """Supplier verification process tracking"""
    
    STATUS_CHOICES = [
        ('initiated', 'Verification Initiated'),
        ('documents_requested', 'Documents Requested'),
        ('documents_received', 'Documents Received'),
        ('under_review', 'Under Review'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ]
    
    supplier = models.OneToOneField(Supplier, on_delete=models.CASCADE, related_name='verification')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='initiated')
    
    # Documents
    documents_required = models.JSONField(default=list)
    documents_submitted = models.JSONField(default=dict)
    
    # Review
    reviewer = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    review_notes = models.TextField(blank=True)
    review_date = models.DateTimeField(null=True, blank=True)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"Verification for {self.supplier.name} - {self.status}"


class RFQ(models.Model):
    """Enhanced RFQ with distribution capabilities"""
    
    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('published', 'Published'),
        ('distributed', 'Distributed to Suppliers'),
        ('quotes_received', 'Quotes Received'),
        ('evaluating', 'Evaluating Quotes'),
        ('awarded', 'Awarded'),
        ('closed', 'Closed'),
    ]
    
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    description = models.TextField()
    category = models.CharField(max_length=100)
    subcategory = models.CharField(max_length=100, blank=True)
    
    # Quantities & Pricing
    quantity = models.IntegerField(validators=[MinValueValidator(1)])
    target_price = models.DecimalField(max_digits=10, decimal_places=2)
    currency = models.CharField(max_length=3, default='USD')
    budget_range = models.CharField(max_length=100, blank=True)  # "$10,000 - $15,000"
    
    # Timeline
    deadline = models.DateTimeField()
    quote_deadline = models.DateTimeField(null=True, blank=True)
    delivery_deadline = models.DateTimeField(null=True, blank=True)
    
    # Distribution Settings
    distribution_method = models.CharField(
        max_length=20,
        choices=[
            ('auto', 'Automatic - AI Matched'),
            ('manual', 'Manual Selection'),
            ('hybrid', 'Hybrid - AI + Manual')
        ],
        default='auto'
    )
    target_supplier_count = models.IntegerField(default=10)
    regions_preferred = models.JSONField(default=list)
    supplier_criteria = models.JSONField(default=dict)
    
    # Status & Tracking
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    responses = models.IntegerField(default=0)
    views = models.IntegerField(default=0)
    
    # Foreign keys
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='rfqs')
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    published_at = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['status']),
            models.Index(fields=['category']),
            models.Index(fields=['deadline']),
            models.Index(fields=['distribution_method']),
        ]
    
    def __str__(self):
        return self.title


class RFQDistribution(models.Model):
    """Track RFQ distribution to suppliers"""
    
    STATUS_CHOICES = [
        ('sent', 'Sent'),
        ('delivered', 'Delivered'),
        ('viewed', 'Viewed'),
        ('responded', 'Responded'),
        ('failed', 'Failed'),
    ]
    
    rfq = models.ForeignKey(RFQ, on_delete=models.CASCADE, related_name='distributions')
    supplier = models.ForeignKey(Supplier, on_delete=models.CASCADE, related_name='rfq_distributions')
    
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='sent')
    sent_at = models.DateTimeField(auto_now_add=True)
    delivered_at = models.DateTimeField(null=True, blank=True)
    viewed_at = models.DateTimeField(null=True, blank=True)
    responded_at = models.DateTimeField(null=True, blank=True)
    
    # Communication tracking
    email_sent = models.BooleanField(default=False)
    notification_sent = models.BooleanField(default=False)
    
    class Meta:
        unique_together = ['rfq', 'supplier']
        ordering = ['-sent_at']
    
    def __str__(self):
        return f"{self.rfq.title} -> {self.supplier.name} ({self.status})"


class CommunicationLog(models.Model):
    """Track all communications with suppliers"""
    
    COMMUNICATION_TYPE_CHOICES = [
        ('email', 'Email'),
        ('phone', 'Phone Call'),
        ('meeting', 'Meeting'),
        ('chat', 'Chat'),
        ('rfq', 'RFQ'),
        ('quote', 'Quote'),
    ]
    
    supplier = models.ForeignKey(Supplier, on_delete=models.CASCADE, related_name='communications')
    contact = models.ForeignKey(SupplierContact, on_delete=models.SET_NULL, null=True, blank=True)
    communication_type = models.CharField(max_length=20, choices=COMMUNICATION_TYPE_CHOICES)
    
    # Communication Details
    subject = models.CharField(max_length=255)
    content = models.TextField()
    direction = models.CharField(max_length=10, choices=[('inbound', 'Inbound'), ('outbound', 'Outbound')])
    
    # Metadata
    initiated_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    related_rfq = models.ForeignKey(RFQ, on_delete=models.SET_NULL, null=True, blank=True)
    related_quote = models.ForeignKey('Quote', on_delete=models.SET_NULL, null=True, blank=True)
    
    # Status
    status = models.CharField(
        max_length=20,
        choices=[
            ('sent', 'Sent'),
            ('delivered', 'Delivered'),
            ('read', 'Read'),
            ('replied', 'Replied'),
            ('failed', 'Failed'),
        ],
        default='sent'
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['supplier', 'communication_type']),
            models.Index(fields=['created_at']),
        ]
    
    def __str__(self):
        return f"{self.supplier.name} - {self.communication_type}: {self.subject}"


class Quote(models.Model):
    """Quote model for supplier responses to RFQs"""
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('accepted', 'Accepted'),
        ('rejected', 'Rejected'),
        ('expired', 'Expired'),
    ]
    
    id = models.AutoField(primary_key=True)
    rfq = models.ForeignKey(RFQ, on_delete=models.CASCADE, related_name='quotes')
    supplier = models.ForeignKey(Supplier, on_delete=models.CASCADE, related_name='quotes')
    product = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    currency = models.CharField(max_length=3, default='USD')
    lead_time = models.IntegerField(help_text="Lead time in days")
    moq = models.IntegerField(help_text="Minimum order quantity")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    specs = models.JSONField(default=dict, help_text="Product specifications")
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
        unique_together = ['rfq', 'supplier']
    
    def __str__(self):
        return f"{self.supplier.name} - {self.product}"


class Message(models.Model):
    """Chat message model for AI assistant conversations"""
    AUTHOR_CHOICES = [
        ('user', 'User'),
        ('ai', 'AI'),
    ]
    
    id = models.AutoField(primary_key=True)
    author = models.CharField(max_length=10, choices=AUTHOR_CHOICES)
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    typing = models.BooleanField(default=False)
    
    # Foreign keys
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='messages')
    
    class Meta:
        ordering = ['timestamp']
    
    def __str__(self):
        return f"{self.author}: {self.content[:50]}..."


class KPI(models.Model):
    """Key Performance Indicators model"""
    id = models.AutoField(primary_key=True)
    saved_cost = models.DecimalField(max_digits=12, decimal_places=2)
    quotes_in_flight = models.IntegerField()
    on_time_rate = models.DecimalField(max_digits=5, decimal_places=2, help_text="Percentage")
    total_orders = models.IntegerField()
    active_suppliers = models.IntegerField()
    avg_lead_time = models.IntegerField(help_text="Average lead time in days")
    
    # Foreign keys
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='kpis')
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"KPI for {self.user.username} - {self.created_at.date()}"
